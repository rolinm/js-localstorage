//variables
const listaCarrito = document.querySelector('#listado-carrito');
const contenedor= document.querySelector('.listado-carrito tbody');
const carrito = document.querySelector('#carrito');
const btnVaciarCarrito = document.querySelector('#vaciar-carrito');
let artiulos = []

cargarListeners()

//listeners
function cargarListeners() {

    listaCarrito.addEventListener('click', agregar);

    //eliminar carrito
    carrito.addEventListener('click', eliminarCarrito);

    btnVaciarCarrito.addEventListener('click', () => {
        artiulos = [];
        crearHTML()
    });

    document.addEventListener('DOMContentLoaded', () => {
        artiulos = JSON.parse(localStorage.getItem('articulos')) || [];
        crearHTML()
    })

}

function eliminarCarrito(e) {
    if(e.target.classList.contains('borrar')) {
        
        const productoId = e.target.getAttribute('id');
        
        artiulos = artiulos.filter(producto=> producto.id !== productoId);
        crearHTML()

    }
}

//funciones

function agregar(e) {
    if(e.target.classList.contains('agregar-producto')) {

        const elemento = e.target.parentElement.parentElement.parentElement;
        
        leerDatos(elemento)
    }
}

function leerDatos(producto) {

    const infoProductos = {
        imagen: producto.querySelector('img').src,
        titulo: producto.querySelector('p').textContent,
        precio: producto.querySelector('.precio').textContent,
        id: producto.querySelector('button').getAttribute('id'),
        cantidad: 1

    }

    //comprobamos si un elemento ya existe en el carrito

    const existe = artiulos.some(articulo => articulo.id === infoProductos.id);
    
    if (existe) {
        const productos = artiulos.map(articulo => {

            if (articulo.id === infoProductos.id) {
                articulo.cantidad++;
                return articulo;
            } else {
                return articulo;
            }

        })

        artiulos = [...productos]
    } else {

        artiulos = [...artiulos, infoProductos]

    }

    crearHTML()

}

function crearHTML() {

    limpiarHTML()

    artiulos.forEach(articulo => {

        const { imagen, titulo, precio, cantidad, id} = articulo

        const row = document.createElement('tr');

        row.innerHTML = `
            <td><img src="${imagen}" width="100"></td>
            <td>${titulo}</td>
            <td>${precio}</td>
            <td>${cantidad}</td>
            <td>
                <a href="#" class="w3-btn w3-round w3-red w3-card w3-small borrar" id="${id}"><i class="fa fa-trash"></i></a>
            </td>
        `;

        contenedor.appendChild(row)

    });

    sincronizarStorage()

}

function limpiarHTML() {

    while (contenedor.firstChild) {
        contenedor.removeChild(contenedor.firstChild)
    }

}

function sincronizarStorage() {

    localStorage.setItem('articulos', JSON.stringify(artiulos));

}